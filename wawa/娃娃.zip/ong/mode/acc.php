<?php return array (
  'acc' => NULL,
  'time' => 1497670758,
);