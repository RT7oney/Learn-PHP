<?php return array (
  'write' => 
  array (
    'h' => 'write',
    'host' => 'localhost',
    'port' => '3306',
    'user' => 'root',
    'pass' => 'root',
    'name' => '37',
    'char' => 'utf8',
    'qian' => 'ay_',
  ),
);