<?php return array (
  0 => '普通会员',
);