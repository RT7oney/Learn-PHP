<?php return array (
  0 => '显示关闭',
  1 => '显示开启',
);