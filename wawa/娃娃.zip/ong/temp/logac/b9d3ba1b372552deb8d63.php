<?php return array (
  0 => '女',
  1 => '男',
);