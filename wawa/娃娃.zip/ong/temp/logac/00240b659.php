<?php return array (
  0 => '关闭',
  1 => '审核',
  2 => '开启',
);