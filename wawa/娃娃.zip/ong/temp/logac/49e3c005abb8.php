<?php return array (
  0 => '关闭',
  1 => '开启',
);