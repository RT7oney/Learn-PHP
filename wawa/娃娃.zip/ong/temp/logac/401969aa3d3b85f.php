<?php return array (
  0 => '否',
  1 => '是',
);