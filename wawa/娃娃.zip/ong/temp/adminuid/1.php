<?php return array (
  'id' => '1',
  'name' => 'admin',
  'pass' => '76c43cc33ce06e51868f57ff986',
  'diqu' => '0',
  'epass' => '00f9d6efc1fd4a4755b1f21f194',
  'type' => '0',
  'yanzhengip' => '1',
  'off' => '1',
  'ip' => '',
  'atime' => '0',
);