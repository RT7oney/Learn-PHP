<?php return array (
  0 => 'id,uid,type,jine,data,ip,atime,name,zhanghao,fs,off',
  1 => 
  array (
    'id' => 'auto_increment',
    'uid' => 'uid_0',
    'type' => 'type_0',
    'jine' => 'jine_0.00',
    'data' => 'data_',
    'ip' => 'ip_',
    'atime' => 'atime_0',
    'name' => 'name_',
    'zhanghao' => 'zhanghao_',
    'fs' => 'fs_',
    'off' => 'off_0',
  ),
);