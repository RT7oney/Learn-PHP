<?php return array (
  0 => 'id,uid,type,data,ip,atime',
  1 => 
  array (
    'id' => 'auto_increment',
    'uid' => 'uid_0',
    'type' => 'type_0',
    'data' => 'data_',
    'ip' => 'ip_',
    'atime' => 'atime_0',
  ),
);