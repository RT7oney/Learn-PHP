<?php return array (
  0 => 'id,type,name,data',
  1 => 
  array (
    'id' => 'auto_increment',
    'type' => 'type_',
    'name' => 'name_',
    'data' => 'data_',
  ),
);