<?php return array (
  0 => 'id,name,pass,diqu,epass,type,yanzhengip,off,ip,atime',
  1 => 
  array (
    'id' => 'auto_increment',
    'name' => 'name_',
    'pass' => 'pass_',
    'diqu' => 'diqu_0',
    'epass' => 'epass_',
    'type' => 'type_0',
    'yanzhengip' => 'yanzhengip_0',
    'off' => 'off_0',
    'ip' => 'ip_',
    'atime' => 'atime_0',
  ),
);