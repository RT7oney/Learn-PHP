<?php return array (
  0 => 'id,uid,type,jine,data,ip,atime',
  1 => 
  array (
    'id' => 'auto_increment',
    'uid' => 'uid_0',
    'type' => 'type_0',
    'jine' => 'jine_0.00',
    'data' => 'data_',
    'ip' => 'ip_',
    'atime' => 'atime_0',
  ),
);