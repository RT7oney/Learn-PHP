<?php return array (
  0 => 'id,name,suoluetu,payid,paykey,zhanghao,off,xianshi,beizhu,paixu,adminid,payfile,isapp',
  1 => 
  array (
    'id' => 'auto_increment',
    'name' => 'name_',
    'suoluetu' => 'suoluetu_',
    'payid' => 'payid_',
    'paykey' => 'paykey_',
    'zhanghao' => 'zhanghao_',
    'off' => 'off_0',
    'xianshi' => 'xianshi_0',
    'beizhu' => 'beizhu_',
    'paixu' => 'paixu_0',
    'adminid' => 'adminid_0',
    'payfile' => 'payfile_',
    'isapp' => 'isapp_0',
  ),
);