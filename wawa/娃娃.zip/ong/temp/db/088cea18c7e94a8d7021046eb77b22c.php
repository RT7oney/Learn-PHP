<?php return array (
  0 => 'id,name,shezhi,miaoshu',
  1 => 
  array (
    'id' => 'auto_increment',
    'name' => 'name_',
    'shezhi' => 'shezhi_',
    'miaoshu' => 'miaoshu_',
  ),
);