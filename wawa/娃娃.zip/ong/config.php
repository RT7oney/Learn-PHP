<?php return array (
  'write' => 
  array (
    'h' => 'write',
    'host' => '127.0.0.1',
    'port' => '3306',
    'user' => 'root',
    'pass' => '317a28bc749e63fe',
    'name' => 'wawa',
    'char' => 'utf8',
    'qian' => 'ay_',
  ),
);
